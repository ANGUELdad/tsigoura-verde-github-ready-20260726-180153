# Tsigoura Verde Resort — e-menu (deploy package)

Ready to upload to **Vercel**. No build step. The menu works as a static site; booking email and admin PIN checks use optional Vercel functions in `api/`.

## What's inside
| File | URL | What it is |
|---|---|---|
| `index.html` | `/` | Customer menu (the QR opens this) |
| `admin.html` | `/admin` | Owner panel (menu, tables, orders, QR, **Πιάτο ημέρας**) |
| `book.html` | `/book` | Full page for table bookings |
| `tsigoura-data.js` | — | All menu data (dishes, prices, categories, tables, settings) |
| `tsigoura-menu-icons.js`, `tsigoura-icons.js`, `tsigoura-qr.js` | — | Icons + QR encoder |
| `media/` | — | Logo, acorn mark, hero photo |
| `api/book.js` | `/api/book` | Booking email endpoint via Resend |
| `api/admin-login.js` | `/api/admin-login` | Admin PIN check from Vercel env |
| `api/public-config.js` | `/api/public-config` | Public contact/Wi-Fi/legal config from env |
| `api/menu.js` | `/api/menu` | Public menu snapshot from Supabase |
| `api/admin-menu.js` | `/api/admin-menu` | Admin save/load endpoint for Supabase |
| `supabase/schema.sql` | — | Supabase tables + RLS setup |
| `.env.example` | — | Environment variable template |
| `vercel.json` | — | Clean URLs + cache headers |

## Deploy (2 minutes)
1. Install once: `npm i -g vercel`
2. From this folder: `vercel` (first run links/creates the project) → then `vercel --prod`
   *Or* drag this folder into the Vercel dashboard → New Project → Deploy.
3. You get `https://<project>.vercel.app`.

## Environment variables
Add these in Vercel: **Project → Settings → Environment Variables**. Use `.env.example` as the complete checklist.

- `RESEND_API_KEY` — your Resend API key
- `BOOKING_TO_EMAIL` or `BOOKING_EMAIL` — where booking requests should arrive
- `BOOKING_FROM_EMAIL` or `RESEND_FROM_EMAIL` — verified sender, e.g. `Tsigoura Verde Resort <bookings@yourdomain.gr>`
- `ADMIN_PIN` — the real admin/waiter PIN
- `SUPABASE_URL` — your Supabase project URL
- `SUPABASE_SERVICE_ROLE_KEY` — server-only Supabase service role/secret key
- `SUPABASE_MENU_TABLE` — default: `tv_menu_state`
- `PUBLIC_PHONE`, `PUBLIC_BOOKING_EMAIL`, `PUBLIC_INSTAGRAM`, `PUBLIC_FACEBOOK`, `PUBLIC_MAPS_URL`, `PUBLIC_WEBSITE_URL`
- `PUBLIC_WIFI_SSID`, `PUBLIC_WIFI_PASS`, `PUBLIC_WIFI_ENC`
- `PUBLIC_COMPANY_NAME`, `PUBLIC_AFM`, `PUBLIC_DOY`, `PUBLIC_GEMI`, `PUBLIC_ADDRESS`, `PUBLIC_MHTE`, `PUBLIC_AGORANOMIKOS`

If Resend is not configured yet, `/book` falls back to a prefilled email draft so customers are not trapped on a dead form.

## Supabase menu database
1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. In Vercel, add `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, and `ADMIN_PIN`.
4. Open `/admin`, log in, go to **Ρυθμίσεις → Supabase βάση δεδομένων**, and press **Αποθήκευση στη βάση** once. That seeds the database with the current menu.
5. After that, customer `/` loads the menu from `/api/menu`, and admin edits auto-save to `/api/admin-menu`.

The browser never receives the Supabase service role key; it stays inside Vercel functions.

## Booking page
Share this link anywhere:

`https://<project>.vercel.app/book`

The menu header booking button opens this full page. The page posts to `/api/book`, and includes a spam honeypot plus required-field validation.

## The QR codes (two kinds — don't mix them)
- **Table QR** (print one per table): `https://<project>.vercel.app/?t=T4` → opens the menu already tagged to table T4. Generate/print these from **/admin → QR & Σύνδεσμοι**.
- **Order QR** (on the customer's screen after ordering): shows the order so the waiter can read/scan it. In this version it carries the order text; the waiter assigns the table if no `?t=` was used.

## Πιάτο ημέρας (today's special)
Owner sets it in **/admin → Επισκόπηση** (name + price + toggle). It appears as a highlighted banner at the top of the customer menu and can be ordered like any dish. Turn the toggle off to hide it.

## Wi-Fi
Guests tap the Wi-Fi icon in the menu header → a **join QR** (camera auto-connects) **plus** a copy-password button.

## Important notes
- This package ships in **traditional e-menu mode by default** for today's upload: guests see menu, availability, event banner, booking, socials, Wi-Fi, and legal info. The ordering systems can be re-enabled from `/admin → Ρυθμίσεις`.
- Without Supabase env vars, menu/admin edits still fall back to each device's `localStorage`. With Supabase configured, the database becomes the shared source of truth.
- Set the real business/legal details, phone, Wi-Fi, booking email, and admin PIN in Vercel env before going public.
- Local preview fallback admin PIN is `1234`; production should use `ADMIN_PIN`.
